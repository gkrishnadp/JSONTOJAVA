package com.dbs.json;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class ReadDatFile {

	public static void main(String[] args) throws FileNotFoundException {
		//File file = new File("D:\\workspace_New\\UBOFEB09\\DATFile\\src\\com\\dbs\\json\\TBL_CASE_LOB_CN_120218.dat");
		File file = new File("D:\\workspace_New\\UBOFEB09\\DATFile\\src\\com\\dbs\\json\\Test.dat");
		Scanner scnr = new Scanner(file);
		int i=0;
		int count =0;
		while(scnr.hasNextLine()){
			if(i==0){
				i++;
				continue;
			}	
		   String line = scnr.nextLine();
		   String [] str = line.split("\\|");
		 System.out.println(Arrays.toString(str));
		// String[] aa=Arrays.toString(str).split(",");
		 System.out.println(str[4]);
		   count++;
		}
		//System.out.println("count :"+count);
	}

}

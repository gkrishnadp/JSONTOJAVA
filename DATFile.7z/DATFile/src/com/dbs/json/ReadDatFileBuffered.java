package com.dbs.json;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadDatFileBuffered {

	public static void main(String[] args) throws ParseException {

        String datFile = "D:\\workspace_New\\UBOFEB09\\DATFile\\src\\com\\dbs\\json\\Test.dat";
        BufferedReader br = null;
        String line = "";
        String datSplitBy = "\\|";
        try {

            br = new BufferedReader(new FileReader(datFile));
           line = br.readLine();
           line = br.readLine();
            while (line != null && !line.isEmpty()) {

                String[] json = line.split(datSplitBy);
                
                if(json[0].matches("TRAILER(.*)")){
                	break;
                }
                
                System.out.println(json[5]);
                
                JSONParser parser = new JSONParser();
                JSONObject json123 = (JSONObject) parser.parse(json[5].toString());
                if(json123 != null){
                	 Set<String> jsonKeys = json123.keySet();
                
				 for (String jsonKey : jsonKeys) {
					 
					 System.out.println(jsonKey +" : "+json123.get(jsonKey));
				 }
    					
                }

                line = br.readLine();
               
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
}

}

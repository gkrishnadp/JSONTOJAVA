package com.json.java;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import javax.json.stream.JsonParser;

public class JsonSimpleReadExample {

    public static void main(String[] args) {
		JSONParser parser = new JSONParser();
		try {
			String jsonString ="{\"cifId\":\"3011735\"}";
			System.out.println(jsonString);
			
			JSONParser js = new JSONParser();
			JSONObject jsonObject= (JSONObject) js.parse(jsonString);
			//Object obj = parser.parse(new FileReader("D:\\ABL\\Webservice\\JSONTOJAVA\\src\\com\\json\\java\\customer.json"));
			//JSONObject jsonObject = (JSONObject) obj;
			
			Set<String> set = jsonObject.keySet();
			
			System.out.println("*************Reading JSON Object ***************");
			for (String s : set) {
				//Object aaa = jsonObject.get(s);
				if ((jsonObject.get(s)) instanceof JSONArray){
					JSONArray jsonArray = (JSONArray) jsonObject.get(s);
					 for (int i=0; i < jsonArray.size() ; i++) {
						 JSONObject jsonObject1 = (JSONObject) jsonArray.get(i);
						 Set<String> ss = jsonObject1.keySet();
						 for (String s1 : ss) {
							System.out.println(s1 + " : "+jsonObject1.get(s1));
						 }
			            }
			    }else if ((jsonObject.get(s)) instanceof JSONObject){
						JSONObject jsonObject2 = (JSONObject) (jsonObject.get(s));
						Set<String> ss2 = jsonObject2.keySet();
						 for (String s2 : ss2) {
							System.out.println(s2 + " : "+jsonObject2.get(s2));
						 }
						
					
			    }else{
			    	System.out.println(s + " : "+jsonObject.get(s));
			    }
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}

}

}
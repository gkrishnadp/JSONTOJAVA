package com.json.java;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

/*import org.json.JSONException;
import org.json.JSONObject;*/

/**
 * @author Crunchify.com
 * 
 */
@SuppressWarnings("deprecation")
public class CrunchifyJSONReadFromFile {
	//private static final String FILENAME = "D:\\ABL\\Webservice\\JSONTOJAVA\\src\\com\\json\\java\\test.json";
	
	public static void main(String[] args)  {
		JSONParser parser = new JSONParser();
//		try {
//			Object obj = parser.parse(new FileReader("D:\\ABL\\Webservice\\JSONTOJAVA\\src\\com\\json\\java\\test1.json"));
//			
//			JSONObject jsonObject = (JSONObject) obj;
//			/*JSONObject updated = (JSONObject) jsonObject.get("updated");
//			String time = (String) updated.get("time");
//			System.out.println(time);*/
//			Object obj1 = jsonObject.get("Company List");
//			JSONArray companyList = (JSONArray) obj1;
//			@SuppressWarnings("unchecked")
//			Iterator<String> iterator = companyList.iterator();
//            while (iterator.hasNext()) {
//                System.out.println(iterator.next());
//            }
//			
//		
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
	
		/* String jsonStr = "{\"name\":\"SK\",\"arr\":{\"a\":\"1\",\"b\":\"2\"}}";
	        JSONObject jsonObj = new JSONObject(jsonStr);
	        String name = jsonObj.getString("name");
	        System.out.println(name);

	        String first = jsonObj.getJSONObject("arr").getString("a");
	        System.out.println(first);*/
	        
	        /*try (BufferedReader br = new BufferedReader(new FileReader(FILENAME))) {

				String sCurrentLine;

				while ((sCurrentLine = br.readLine()) != null) {
					System.out.println(sCurrentLine);
				}

			} catch (IOException e) {
				e.printStackTrace();
			}*/
		
		
		
		
		 String datFile = "D:\\workspace_New\\UBOFEB09\\DATFile\\src\\com\\dbs\\json\\Test.dat";
	        BufferedReader br = null;
	        String line = "";
	        String datSplitBy = "\\|";
	        try {

	            br = new BufferedReader(new FileReader(datFile));
	           line = br.readLine();
	           line = br.readLine();
	           
	           while (line != null && !line.isEmpty()) {

	                String[] json = line.split(datSplitBy);
	                
	                if(json[0].matches("TRAILER(.*)")){
	                	break;
	                }
	                
	                System.out.println(json[5]);
	                
	               // JSONParser parser = new JSONParser();
	                Object obj1 = parser.parse(json[5].toString());
	               // System.out.println(obj1.getClass());
	                if(obj1 != null){
	                /*Set<String> jsonKeys = json123.keySet();
					 for (String jsonKey : jsonKeys) {
						 System.out.println(jsonKey +" : "+json123.get(jsonKey));
					 }*/
	                	if ((obj1) instanceof JSONArray){
	                		System.out.println("JSONArray");
	                		
	                		JSONArray jsonArray = (JSONArray) obj1;
	       				 for (int i=0; i < jsonArray.size() ; i++) {
	       					 JSONObject jsonObject1 = (JSONObject) jsonArray.get(i);
	       					 Set<String> jsonKeys = jsonObject1.keySet();
	       					 for (String jsonKey : jsonKeys) {
	       						 
	       						 System.out.println(jsonKey+" : "+jsonObject1.get(jsonKey).toString());
	       						
	       					 }
	       		            }
	       				 
	                	}else if ((obj1) instanceof JSONObject){
	                		System.out.println("JSONObject");
	                		
	                		JSONObject jsonObject1 = (JSONObject) obj1;
	       				 Set<String> jsonKeys = jsonObject1.keySet();
	       				 for (String jsonKey : jsonKeys) {

	       						if ((jsonObject1.get(jsonKey)) instanceof JSONArray){
	       							JSONArray jsonArray = (JSONArray) jsonObject1.get(jsonKey);
	       							 for (int i=0; i < jsonArray.size() ; i++) {
	       								 JSONObject jsonObject = (JSONObject) jsonArray.get(i);
	       								 Set<String> jsonKeys1 = jsonObject.keySet();
	       								 for (String jsonKey1 : jsonKeys1) {
	       									System.out.println(jsonKey1 +" : "+jsonObject.get(jsonKey1));
	       								 }
	       					            }
	       					    }else if ((jsonObject1.get(jsonKey)) instanceof JSONObject){
	       								JSONObject jsonObject2 = (JSONObject) (jsonObject1.get(jsonKey));
	       								Set<String> objectKeys1 = jsonObject2.keySet();
	       								 for (String objectKey1 : objectKeys1) {
	       										 System.out.println(objectKey1 +" : "+jsonObject2.get(objectKey1));
	       								 }
	       					    }else{
	       					    	System.out.println(jsonKey +" : "+jsonObject1.get(jsonKey));
	       					    }
	       					
	       				 }
	                		
	                		
	                		
	                		
	                		
	                		
	                		
	                	}
					 
	                }

	                line = br.readLine();
	               
	            }
	           
	        }catch(Exception e){
	        	
	        }
		
		
		/*
		try{
			System.out.println("*****");
			Object obj = parser.parse(new FileReader("D:\\ABL\\Webservice\\JSONTOJAVA\\src\\com\\json\\java\\ideal.json")); // Change the file path - json file
			if ((obj) instanceof JSONArray){
				System.out.println("array");
				
				JSONArray jsonArray = (JSONArray) obj;
				 for (int i=0; i < jsonArray.size() ; i++) {
					 JSONObject jsonObject1 = (JSONObject) jsonArray.get(i);
					 Set<String> jsonKeys = jsonObject1.keySet();
					 for (String jsonKey : jsonKeys) {
						 
						 System.out.println(jsonKey+" : "+jsonObject1.get(jsonKey).toString());
						
					 }
		            }
				 
			}else if ((obj) instanceof JSONObject){
				System.out.println("object");
				JSONObject jsonObject1 = (JSONObject) obj;
				 Set<String> jsonKeys = jsonObject1.keySet();
				 for (String jsonKey : jsonKeys) {

						if ((jsonObject1.get(jsonKey)) instanceof JSONArray){
							JSONArray jsonArray = (JSONArray) jsonObject1.get(jsonKey);
							 for (int i=0; i < jsonArray.size() ; i++) {
								 JSONObject jsonObject = (JSONObject) jsonArray.get(i);
								 Set<String> jsonKeys1 = jsonObject.keySet();
								 for (String jsonKey1 : jsonKeys1) {
									System.out.println(jsonKey1 +" : "+jsonObject.get(jsonKey1));
								 }
					            }
					    }else if ((jsonObject1.get(jsonKey)) instanceof JSONObject){
								JSONObject jsonObject2 = (JSONObject) (jsonObject1.get(jsonKey));
								Set<String> objectKeys1 = jsonObject2.keySet();
								 for (String objectKey1 : objectKeys1) {
										 System.out.println(objectKey1 +" : "+jsonObject2.get(objectKey1));
								 }
					    }else{
					    	System.out.println(jsonKey +" : "+jsonObject1.get(jsonKey));
					    }
					
				 }
			}else{
				System.out.println("oooo");
			}
			
		}catch(Exception e){                   
			
		}
		*/
		
		
		
		
		
		
	}
	
	
}

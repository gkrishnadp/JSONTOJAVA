
/* Extracting the JSON Object : 
	 * input  : customer.json, odAccounts.json, ideal.json
	 * output : channelPartnerId,customerSegment,documentCode,emailAddres,isPrimary,localLRM,masIndustry,solID,tallyId,uniqueId  
 */

package com.json.java;

import java.io.FileReader;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class ExtractJSON {

	public static void main(String[] args) {
		Map<String, String>  hashMap = new HashMap<String, String>();
		JSONParser parser = new JSONParser();
		try {
			Object obj = parser.parse(new FileReader("D:\\ABL\\Webservice\\JSONTOJAVA\\src\\com\\json\\java\\customer.json"));// Change the customer JSON path
			JSONObject jsonObject = (JSONObject) obj;
			Set<String> objectSets = jsonObject.keySet();
			String str = "";
			int emainConcat = 1; 
			for (String objectSet : objectSets) {
				if ((jsonObject.get(objectSet)) instanceof JSONArray){
					JSONArray jsonArray = (JSONArray) jsonObject.get(objectSet);
					 for (int i=0; i < jsonArray.size() ; i++) {
						 JSONObject jsonObject1 = (JSONObject) jsonArray.get(i);
						 Set<String> jsonKeys = jsonObject1.keySet();
						 for (String jsonKey : jsonKeys) {
							 if(jsonKey.equalsIgnoreCase("emailAddress")){ // Extracting Email Address attribute - object - array - object
								 if(emainConcat>1){
									 str+=" | "+jsonObject1.get(jsonKey);
									 hashMap.put(jsonKey, str);
								 }else{
									 str=(String) jsonObject1.get(jsonKey);
									 hashMap.put(jsonKey, str);
								 }
								 emainConcat++;
							 }
							 if(jsonKey.equalsIgnoreCase("documentCode")){ // Extracting documentCode attribute - object - array - object 
								 
								 hashMap.put(jsonKey, jsonObject1.get(jsonKey).toString());
							 }
							 
							 if(jsonKey.equalsIgnoreCase("uniqueId")){ // Extracting uniqueId attribute - object - array - object 
								 
								 hashMap.put(jsonKey, jsonObject1.get(jsonKey).toString());
							 }
							 
							 if(jsonKey.equalsIgnoreCase("isPrimary")){ // Extracting isPrimary attribute - object - array - object  
								 
								 hashMap.put(jsonKey, jsonObject1.get(jsonKey).toString());
							 }
						 }
			            }
			    }else if ((jsonObject.get(objectSet)) instanceof JSONObject){
						JSONObject jsonObject2 = (JSONObject) (jsonObject.get(objectSet));
						Set<String> objectKeys = jsonObject2.keySet();
						 for (String objectKey : objectKeys) {
							 if(objectKey.equalsIgnoreCase("localLRM")){  // Extracting localLRM attribute - object in object
						    		hashMap.put(objectKey, jsonObject.get(objectKey).toString());
						    	}
						    	if(objectKey.equalsIgnoreCase("customerSegment")){ // Extracting customerSegment attribute object in object
						    		hashMap.put(objectKey, jsonObject.get(objectKey).toString());
						    	}
						    	if(objectKey.equalsIgnoreCase("masIndustry")){ // Extracting masIndustry attribute in -object object in object 
						    		hashMap.put(objectKey, jsonObject.get(objectKey).toString());
						    	}			    	
						    	if(objectKey.equalsIgnoreCase("channelPartnerId")){ // Extracting channelPartnerId attribute -object in object 
						    		hashMap.put(objectKey, jsonObject.get(objectKey).toString());
						    	}
						    	
						    	if(objectKey.equalsIgnoreCase("documentCode")){ // Extracting documentCode attribute -object in object 
									 
						    		 hashMap.put(objectKey, jsonObject.get(objectKey).toString());
								 }
								 
								 if(objectKey.equalsIgnoreCase("uniqueId")){ // Extracting uniqueId attribute - object in object  
									 
									 hashMap.put(objectKey, jsonObject.get(objectKey).toString());
								 }
								 
								 if(objectKey.equalsIgnoreCase("isPrimary")){ // Extracting isPrimary attribute - object in object 
									 
									 hashMap.put(objectKey, jsonObject.get(objectKey).toString());
								 }
						 }
			    }else{
			    	if(objectSet.equalsIgnoreCase("localLRM")){   // Extracting localLRM attribute in object
			    		hashMap.put(objectSet, jsonObject.get(objectSet).toString());
			    	}
			    	if(objectSet.equalsIgnoreCase("customerSegment")){ // Extracting customerSegment attribute in object
			    		hashMap.put(objectSet, jsonObject.get(objectSet).toString());
			    	}
			    	if(objectSet.equalsIgnoreCase("masIndustry")){ // Extracting masIndustry attribute in object
			    		hashMap.put(objectSet, jsonObject.get(objectSet).toString());
			    	}
			    	
			    	if(objectSet.equalsIgnoreCase("channelPartnerId")){ // Extracting channelPartnerId attribute in object
			    		hashMap.put(objectSet, jsonObject.get(objectSet).toString());
			    	}
			    }
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Object obj = parser
					.parse(new FileReader(
							"D:\\ABL\\Webservice\\JSONTOJAVA\\src\\com\\json\\java\\odAccounts.json")); // Change the fodAccounts JSON path
			JSONArray jsonArray = (JSONArray) obj;
			for (int i = 0; i < jsonArray.size(); i++) {
				JSONObject jsonObject1 = (JSONObject) jsonArray.get(i);
				Set<String> objectKeys = jsonObject1.keySet();

				for (String objectKey : objectKeys) {
					if (objectKey.equalsIgnoreCase("solID")) {  // Extracting solID attribute - Array - Object
						hashMap.put(objectKey, jsonObject1.get(objectKey).toString());
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		try{
			Object obj = parser.parse(new FileReader("D:\\ABL\\Webservice\\JSONTOJAVA\\src\\com\\json\\java\\ideal.json")); // Change the ideal JSON path 
			JSONObject jsonObject = (JSONObject) obj;
			Set<String> ObjectKeys = jsonObject.keySet();
			for (String ObjectKey : ObjectKeys) {
			 if ((jsonObject.get(ObjectKey)) instanceof JSONObject){
						JSONObject jsonObject2 = (JSONObject) (jsonObject.get(ObjectKey));
						Set<String> ObjectKeys1 = jsonObject2.keySet();
						 for (String ObjectKey1 : ObjectKeys1) {
							 if(ObjectKey1.equalsIgnoreCase("tallyId")){  // Extracting solID attribute - Object - Object
						    		hashMap.put(ObjectKey1, jsonObject2.get(ObjectKey1).toString());
						    	}
						 }
			    }else{
			    	if(ObjectKey.equalsIgnoreCase("tallyId")){
			    		if(jsonObject.get(ObjectKey) == null){
			    			hashMap.put(ObjectKey, "NULL");
			    		}else{
			    			hashMap.put(ObjectKey, jsonObject.get(ObjectKey).toString());
			    		}
			    	}
			    }
			}
		}catch(Exception e){
			
		}
		System.out.println("*************Extracting JSON ***************");
		 Map<String, String> treeMap = new TreeMap<String, String>(hashMap);
		 Set s = treeMap.entrySet();
		    Iterator it = s.iterator();
		    while ( it.hasNext() ) {
		       Map.Entry entry = (Map.Entry) it.next();
		       System.out.println(entry.getKey() + " : " + entry.getValue());
		    }
}
}

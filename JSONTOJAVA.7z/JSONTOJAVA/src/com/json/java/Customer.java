package com.json.java;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class Customer {

		public static void main(String[] args)  {
			JSONParser parser = new JSONParser();
			try {
				
				
				@SuppressWarnings("deprecation")
				Object obj = parser.parse(new FileReader("D:\\ABL\\Webservice\\JSONTOJAVA\\src\\com\\json\\java\\test.json"));
				
				JSONObject jsonObject = (JSONObject) obj;
								  //Get Array Values
				
	            JSONArray genreArray = (JSONArray) jsonObject.get("person");
	            // get the first genre
	           /* JSONObject firstGenre = (JSONObject) genreArray.get(0);
	            System.out.println(firstGenre.get("name"));
	            // get the Second
	             JSONObject firstGenre1 = (JSONObject) genreArray.get(1);
	            System.out.println(firstGenre.get("city"));
	            */
	            //JSONObject jo ;
	            for (int i=0; i < genreArray.size() ; i++) {
	            	jsonObject= (JSONObject) genreArray.get(i);
	            	System.out.println(jsonObject.get("name")+" : "+jsonObject.get("city"));
	            	
	            }
	            
	            /* // get the third
	            JSONObject firstGenre2 = (JSONObject) genreArray.get(2);
	            System.out.println(firstGenre.get("city"));*/
				
				
				
				/*for(Iterator iterator = jsonObject.keySet().iterator(); iterator.hasNext();) {
				    String key = (String) iterator.next();
				    System.out.println(jsonObject.get(key).getClass());
				    
				}*/
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		

			
		}
		
		
}
